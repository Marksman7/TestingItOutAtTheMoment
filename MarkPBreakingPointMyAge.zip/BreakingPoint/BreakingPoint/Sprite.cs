﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BreakingPoint
{
    class Sprite
    {
        //GraphicsDeviceManager graphics;

        protected Texture2D Texture;

        protected Vector2 Location;
        protected Vector2 Direction;
        protected float Speed = 0;

        protected int[] Tracker = new int[20];

        protected int PresetNumberOn = -1;

        public string TextureName { get; set; }

        protected Game game;

        public Sprite(Game game)
        {
            this.game = game;

        }

        public int Preset()
        {
            PresetNumberOn = PresetNumberOn + 1;

            return Tracker[PresetNumberOn];
        }

        public void Preseter()
        {
            for (int k = 0; k < Tracker.Length; k++)
            {
                Tracker[k] = (k * 10);
            }
        }

        private int TrackerNumber()
        {
            bool GoOn = false;
            Random Randies = new Random();
            int OK = 0;
            int Value = 0;

            int Here = 0;
            while (GoOn == false)
            {
                OK = 0;
                Here = Randies.Next(-200, 200);

                for (int i = 0; i < Tracker.Length; i++)
                {
                    if ((Tracker[i] - 10) <= Here && Here >= (Tracker[i] + 10))
                    {
                        OK++;
                    }
                    else
                    {
                        Value = i;
                    }
                }

                if(OK < Tracker.Length)
                {
                    Tracker[Value] = Here;
                    GoOn = true;
                }

            }
            return Here;
        }

        public virtual void LoadContent(int Xvalue, int Yvalue, int DirectionValueX, int DirectionValueY)
        {
            //Preseter();

            if (string.IsNullOrEmpty(TextureName))
            {
                TextureName = "WhiteTrooper05";
            }
            Random Randy = new Random();


            this.Location = new Vector2((game.GraphicsDevice.Viewport.Width / 2) + Xvalue, (game.GraphicsDevice.Viewport.Height / 2) + Yvalue);

            // TODO: use this.Content to load your game content here

            this.Direction = new Vector2(DirectionValueX, DirectionValueY);


            Texture = game.Content.Load<Texture2D>(TextureName);

            Speed = Randy.Next(100, 300);
        }

        

        public virtual void Update(GameTime gameTime)
        {
            //time = (float)gameTime.ElapsedGameTime.TotalMilliseconds;
            //UpdateStuffScreenView();
            //this.Location = this.Location + ((this.Direction * this.Speed) * (time / 1000));
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {

            spriteBatch.Draw(this.Texture, new Rectangle(        //Create rectange to draw to
                    (int)this.Location.X,
                    (int)this.Location.Y,
                    (int)(this.Texture.Width),
                    (int)(this.Texture.Height)),
                null, Color.White);

        }

    }
}