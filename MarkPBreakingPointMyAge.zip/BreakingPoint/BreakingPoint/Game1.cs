﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace BreakingPoint
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        


        SpeedDemon SD;

        SpeedDemon Zeno;

        SpeedDemon Mitch;

        SpeedDemon Peterr;

        SpeedDemon Prince;

        SpeedDemon Parker;

        SpeedDemon Sam;

        SpeedDemon Holland;

        SpeedDemon Perice;

        SpeedDemon SD09;

        SpeedDemon SD10;

        SpeedDemon SD11;

        SpeedDemon SD12;

        SpeedDemon SD13;

        SpeedDemon SD14;

        SpeedDemon SD15;

        SpeedDemon SD16;

        SpeedDemon SD17;

        SpeedDemon SD18;

        //SpriteFont font;

        FPSClass fps;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            SD = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            Zeno = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            Mitch = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            Peterr = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            Prince = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            Parker = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            Sam = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            Holland = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            Perice = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD09 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD10 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD11 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD12 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD13 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD14 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD15 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD16 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD17 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };

            SD18 = new SpeedDemon(this) { TextureName = "WhiteTrooper05" };


            //TargetElapsedTime = TimeSpan.FromTicks(333333);


        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            SD.LoadContent(0, 0, 1, 0);

            Zeno.LoadContent(50, 50, -1, 0);

            Mitch.LoadContent(-50, -50, 1, 1);

            Peterr.LoadContent(25, 25, 3, 1);

            Prince.LoadContent(-175, -175, -3, -1);

            Parker.LoadContent(-175, -175, 1, 3);

            Sam.LoadContent(-150, -150, -1, -3);

            Holland.LoadContent(150, 150, -1, -1);

            Perice.LoadContent(-25, -25, 0, 1);
            
            SD09.LoadContent(-75, -75, 1, 2);
            
            SD10.LoadContent(125, 125, -1, -2);
            
            SD11.LoadContent(-125 , -125, -2, -1);
            
            SD12.LoadContent(75, 75, 2, 1);
            
            SD13.LoadContent(100, 100, -2, -2);
            
            SD14.LoadContent(-10, -100, 2, -2);
            
            SD15.LoadContent(125, 125, 2, 2);

            SD16.LoadContent(-125, -125, -2, 2);

            SD17.LoadContent(-200, -200, 3, 2);

            SD18.LoadContent(200, 200, 2, 3);

            fps = new FPSClass(this);


            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            SD.Update(gameTime);

            Zeno.Update(gameTime);
            
            Mitch.Update(gameTime);

            Peterr.Update(gameTime);

            Prince.Update(gameTime);

            Parker.Update(gameTime);

            Sam.Update(gameTime);

            Holland.Update(gameTime);

            Perice.Update(gameTime);
            
            SD09.Update(gameTime);
            
            SD10.Update(gameTime);
            
            SD11.Update(gameTime);
            
            SD12.Update(gameTime);
            
            SD13.Update(gameTime);
            
            SD14.Update(gameTime);
            
            SD15.Update(gameTime);

            SD16.Update(gameTime);

            SD17.Update(gameTime);

            SD18.Update(gameTime);


            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            spriteBatch.Begin();

            SD.Draw(spriteBatch);

            Zeno.Draw(spriteBatch);
            
            Mitch.Draw(spriteBatch);

            Peterr.Draw(spriteBatch);

            Prince.Draw(spriteBatch);

            Parker.Draw(spriteBatch);

            Sam.Draw(spriteBatch);

            Holland.Draw(spriteBatch);

            Perice.Draw(spriteBatch);
            
            SD09.Draw(spriteBatch);
            
            SD10.Draw(spriteBatch);
            
            SD11.Draw(spriteBatch);
            
            SD12.Draw(spriteBatch);
            
            SD13.Draw(spriteBatch);
            
            SD14.Draw(spriteBatch);
            
            SD15.Draw(spriteBatch);

            SD16.Draw(spriteBatch);

            SD17.Draw(spriteBatch);

            SD18.Draw(spriteBatch);

            fps.Draw(gameTime);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
