﻿using Microsoft.Xna.Framework;
using System;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BreakingPoint
{
    class SpeedDemon : Sprite
    {
        float time;
        private bool BounceOn = false;
        private bool PacmanOn = true;
        Random Randy = new Random();

        KeyboardHandler inputKeyboard;

        enum SpeedDemonState { Bonce, Pacman};
        SpeedDemonState CurrentState;

        public SpeedDemon(Game game) : base(game)
        {
            inputKeyboard = new KeyboardHandler();
        }

        /*public override void LoadContent()
        {

            this.Location = new Vector2((game.GraphicsDevice.Viewport.Width / 2) + Randy.Next(-100, 100), (game.GraphicsDevice.Viewport.Height / 2) + Randy.Next(-100, 100));

            base.LoadContent();

            Speed = Randy.Next(100, 300);
        }*/

        public override void Update(GameTime gameTime)
        {
            time = (float)gameTime.ElapsedGameTime.TotalMilliseconds;

            this.Location = this.Location + (((this.Direction * Speed) * (time / 1000)));


            //this.Location = this.Location; //+ ((this.Direction /* this.Speed*/) * (time / 1000));

            StateChangeTester();

            if (PacmanOn == false && BounceOn == true)
            {
                UpdateBounceStyleOnScreen();
            }
            else
            {
                UpdatePacmanStyleOnScreen();
            }

            Speedchanger();

            UpdateInputKeyboardStuff();

            UpdateThistoNormalIt();

            StateAcutalChange();

            base.Update(gameTime);

        }

        private void Speedchanger()
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Q))
            {
                Speed = Speed + 1000;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.A))
            {
                Speed = Speed + 100;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Z))
            {
                Speed = Speed + 10;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.W))
            {
                Speed = Speed - 1000;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.S))
            {
                Speed = Speed - 100;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.X))
            {
                Speed = Speed - 10;
            }
        }

        private void StateAcutalChange()
        {
            if (Keyboard.GetState().IsKeyDown(Keys.B))
            {
                CurrentState = SpeedDemonState.Bonce;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.P))
            {
                CurrentState = SpeedDemonState.Pacman;
            }
        }

        private void UpdateThistoNormalIt()
        {
            if (Direction.Length() >= 1.0)
            {
                Direction.Normalize();
            }
        }

        private void UpdatePacmanStyleOnScreen()
        {
            if (Location.X > Texture.GraphicsDevice.Viewport.Width - Texture.Width)
            {
                Direction *= new Vector2(-1, 0);
                Location.X = 0;
            }

            if ((Location.X < 0))
            {
                Direction *= new Vector2(-1, 0);
                Location.X = Texture.GraphicsDevice.Viewport.Width - Texture.Width;
            }

            if (Location.Y > Texture.GraphicsDevice.Viewport.Height - Texture.Height)
            {
                Direction *= new Vector2(0, -1);
                Location.Y = 0;
            }

            if ((Location.Y < 0))
            {
                Direction *= new Vector2(0, -1);
                Location.Y = Texture.GraphicsDevice.Viewport.Height - Texture.Height;
            }
        }

        private void StateChangeTester()
        {
            switch (CurrentState)
            {
                case SpeedDemonState.Bonce:
                    BounceOn = true;
                    PacmanOn = false;

                    break;

                case SpeedDemonState.Pacman:
                    PacmanOn = true;
                    BounceOn = false;
                    break;

            }
        }

        private void UpdateBounceStyleOnScreen()
        {

            if (Location.X > this.game.GraphicsDevice.Viewport.Width - Texture.Width || Location.X < 0)
            {
                Direction = Direction * new Vector2(-1, 1);
            }

            if (Location.Y > this.game.GraphicsDevice.Viewport.Height - Texture.Height || Location.Y < 0)
            {
                Direction = Direction * new Vector2(1, -1);
            }


        }

        public void UpdateInputKeyboardStuff()
        {
            inputKeyboard.Update();


            if (Keyboard.GetState().IsKeyDown(Keys.Down))
            {
                Direction += new Vector2(0, 1);
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Up))
            {
                Direction += new Vector2(0, -1);
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                Direction += new Vector2(1, 0);
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                Direction += new Vector2(-1, 0);
            }
        }

    }
}